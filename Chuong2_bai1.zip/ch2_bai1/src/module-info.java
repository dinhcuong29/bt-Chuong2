/**
 * 
 */
/**
 * @author pc
 *
 */
module ch2_bai1 {
}